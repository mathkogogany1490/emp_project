export interface Employee {
    id: string;
    name: string;
    age: number;
    job: string;
    language: string;
    pay: number;
}